window.onload = function () {
  const svgData = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svgData.setAttribute("width", "400");
  svgData.setAttribute("height", "400");
  let circleR = ['200', '180', '160', '140', '110', '90', '70', '50', '30', '10'];
  for (let m = 0; m < circleR.length; m++) {
    let circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    circle.setAttribute("cx", 200);
    circle.setAttribute("cy", 200);
    circle.setAttribute("r", circleR[m]);
    if (m % 2 == 0) {
      let fillColor = "rgb(" + Math.floor(Math.random() * 128) * 2 + "," + Math.floor(Math.random() * 128) * 2 + "," + Math.floor(Math.random() * 128) * 2 + ")";
      circle.setAttribute("fill", fillColor);
    } else {
      let fillColor = "rgb(" + (Math.floor(Math.random() * 128) * 2 + 1) + "," + (Math.floor(Math.random() * 128) * 2 + 1) + "," + (Math.floor(Math.random() * 128) * 2 + 1) + ")";
      circle.setAttribute("fill", fillColor);
    }
    svgData.appendChild(circle);
  }
  document.querySelector('.main').appendChild(svgData)
}


setInterval(() => {
  const circles = document.querySelectorAll('circle');
  for (let i = 0; i < circles.length; i++) {
    const circle = circles[i];
    if (i % 2 == 0) {
      let fillColor = "rgb(" + Math.floor(Math.random() * 128) * 2 + "," + Math.floor(Math.random() * 128) * 2 + "," + Math.floor(Math.random() * 128) * 2 + ")";
      circle.setAttribute("fill", fillColor);
    } else {
      let fillColor = "rgb(" + (Math.floor(Math.random() * 128) * 2 + 1) + "," + (Math.floor(Math.random() * 128) * 2 + 1) + "," + (Math.floor(Math.random() * 128) * 2 + 1) + ")";
      circle.setAttribute("fill", fillColor);
    }
  }
}, 1000);